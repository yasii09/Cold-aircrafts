YASI GPT — FLIGHT OPS (Android Studio project)
================================================

This is a native Android/Kotlin starter project (not an HTML wrapper).
It is configured for landscape orientation and a custom Canvas-rendered 2D arcade game.

To build an APK:
1. Install Android Studio (recent version).
2. Open this folder as an existing project.
3. Allow Gradle sync and install Android SDK Platform 35 if prompted.
4. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
5. The APK will be under app/build/outputs/apk/debug/.

Notes:
- This deliverable is the Android Studio source project, not a precompiled APK.
- This environment does not have Android SDK/Gradle installed, so an APK could not be compiled here.
- Graphics in this prototype are drawn with native Canvas primitives; the supplied concept art is a visual target, not sliced game sprites.
- This is an early playable prototype. Some controls and mission progression need further polish.
