package com.yasigpt.flightops

import android.app.Activity
import android.os.Bundle
import android.view.*
import android.graphics.*
import android.content.Context
import android.content.pm.ActivityInfo
import kotlin.math.*
import kotlin.random.Random

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
            or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_LAYOUT_STABLE)
        setContentView(FlightView(this))
    }
}

class FlightView(context: Context) : View(context) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rnd = Random(7)
    private var page = "menu"
    private var mission = 1
    private var level = 1
    private var planeIndex = 0
    private var showEffects = true
    private val planes = listOf("F-5", "F-14", "F-4", "F-16", "SU-57", "SU-30")
    private var unlocked = 1
    private var airborne = false
    private var paused = false
    private var world = 0f
    private var jetY = 0f
    private var hp = 100f
    private var bombs = 4
    private var flares = 3
    private var score = 0
    private var fireUntil = 0L
    private var left = false
    private var right = false
    private var last = System.nanoTime()
    private data class Target(var x: Float, var y: Float, var hp: Int = 1, var alive: Boolean = true, val apc: Boolean = false)
    private data class Shot(var x: Float, var y: Float)
    private val targets = mutableListOf<Target>()
    private val shots = mutableListOf<Shot>()
    private val explosions = mutableListOf<Triple<Float, Float, Int>>()

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        val w = width.toFloat(); val h = height.toFloat()
        if (w < 1 || h < 1) return
        when (page) {
            "menu" -> drawMenu(c,w,h)
            "missions" -> drawMissions(c,w,h)
            "hangar" -> drawHangar(c,w,h)
            "levels" -> drawLevels(c,w,h)
            "settings" -> drawSettings(c,w,h)
            "game" -> drawGame(c,w,h)
        }
        postInvalidateOnAnimation()
    }
    private fun paint(color:Int, style:Paint.Style=Paint.Style.FILL, sw:Float=1f):Paint {
        p.color=color; p.style=style; p.strokeWidth=sw; p.shader=null; p.textAlign=Paint.Align.LEFT; return p
    }
    private fun rect(c:Canvas,x:Float,y:Float,w:Float,h:Float,color:Int,r:Float=12f) {
        c.drawRoundRect(x,y,x+w,y+h,r,r,paint(color))
    }
    private fun text(c:Canvas,s:String,x:Float,y:Float,size:Float,color:Int=Color.WHITE,bold:Boolean=false,center:Boolean=false) {
        val q=Paint(Paint.ANTI_ALIAS_FLAG); q.color=color; q.textSize=size; q.typeface=if(bold) Typeface.create("sans-serif",Typeface.BOLD) else Typeface.create("sans-serif",Typeface.NORMAL)
        q.textAlign=if(center) Paint.Align.CENTER else Paint.Align.LEFT; c.drawText(s,x,y,q)
    }
    private fun bg(c:Canvas,w:Float,h:Float) {
        val sh=LinearGradient(0f,0f,0f,h,Color.rgb(10,22,37),Color.rgb(25,48,56),Shader.TileMode.CLAMP)
        p.shader=sh;c.drawRect(0f,0f,w,h,p);p.shader=null
        // distant layered mountain silhouettes
        for (layer in 0..2) {
            val path=Path(); path.moveTo(0f,h*.66f+layer*15)
            var x=0f
            while(x<=w+100){ val yy=h*(.48f+layer*.055f)+sin((x+world*(.12f+layer*.08f))*.009f)*h*.045f; path.lineTo(x,yy);x+=55f }
            path.lineTo(w,h);path.lineTo(0f,h);path.close()
            c.drawPath(path,paint(intArrayOf(Color.rgb(37,62,78),Color.rgb(39,67,65),Color.rgb(39,66,49))[layer]))
        }
        rect(c,0f,h*.78f,w,h*.22f,Color.rgb(45,62,52),0f)
        rect(c,0f,h*.82f,w,h*.075f,Color.rgb(59,68,72),0f)
        for(i in 0..(w/80).toInt()+2){val x=((i*80-world*.8f)%(w+80)+w+80)%(w+80);rect(c,x,h*.855f,36f,3f,Color.LTGRAY,1f)}
        // clouds
        if(showEffects) for(i in 0..8){val x=((i*190-world*.22f)%(w+220)+w+220)%(w+220)-80; p.color=0x558FB0C4; c.drawOval(x,h*(.16f+(i%3)*.09f),x+85,h*(.19f+(i%3)*.09f),p)}
    }
    private fun jet(c:Canvas,x:Float,y:Float,scale:Float=1f,color:Int=Color.rgb(180,204,219)) {
        c.save();c.translate(x,y);c.scale(scale,scale)
        val path=Path().apply{moveTo(-45f,0f);lineTo(-10f,-5f);lineTo(6f,-30f);lineTo(16f,-30f);lineTo(12f,-5f);lineTo(46f,0f);lineTo(12f,5f);lineTo(16f,25f);lineTo(6f,25f);lineTo(-10f,5f);close()}
        c.drawPath(path,paint(Color.BLACK));c.save();c.translate(0f,-3f);c.drawPath(path,paint(color));c.restore()
        c.drawOval(-53f,-3f,-40f,3f,paint(Color.rgb(255,151,82)));c.restore()
    }
    private fun target(c:Canvas,t:Target,w:Float) {
        val x=t.x-world*.58f;if(x < -70 || x>w+60)return
        rect(c,x-24,t.y,48f,12f,Color.rgb(24,35,30),3f)
        rect(c,x-20,t.y-9,38f,10f,if(t.apc) Color.rgb(121,151,115) else Color.rgb(154,157,105),3f)
        rect(c,x-5,t.y-14,19f,7f,Color.rgb(80,101,73),2f)
        for(i in 0..3){p.color=Color.rgb(17,25,22);c.drawCircle(x-15+i*10,t.y+10,4f,p)}
        if(t.hp>1){rect(c,x-18,t.y-22,36f,3f,Color.DKGRAY,1f);rect(c,x-18,t.y-22,36f*t.hp/3f,3f,Color.CYAN,1f)}
    }
    private fun button(c:Canvas,label:String,x:Float,y:Float,w:Float,h:Float,active:Boolean=false) {
        rect(c,x,y,w,h,if(active) Color.rgb(16,75,105) else Color.rgb(17,32,49),14f)
        p.color=if(active) Color.CYAN else Color.rgb(62,91,116);p.style=Paint.Style.STROKE;p.strokeWidth=2f;c.drawRoundRect(x,y,x+w,y+h,14f,14f,p);p.style=Paint.Style.FILL
        text(c,label,x+w/2,y+h/2+7, min(22f,h*.28f),Color.WHITE,true,true)
    }
    private fun drawMenu(c:Canvas,w:Float,h:Float) {
        bg(c,w,h); text(c,"YASI GPT",w*.08f,h*.22f,48f,Color.WHITE,true);text(c,"FLIGHT OPS",w*.085f,h*.29f,22f,Color.CYAN,true)
        jet(c,w*.68f,h*.34f,2.3f,Color.rgb(181,204,218));jet(c,w*.84f,h*.54f,1.0f,Color.rgb(91,125,148))
        val labels=listOf("MISSIONS","FREE MISSION","HANGAR","SETTINGS")
        labels.forEachIndexed{i,s->button(c,s,w*.08f,h*(.37f+i*.14f),w*.34f,h*.105f,i==0)}
        text(c,"2D ARCADE FLIGHT • ANDROID",w*.08f,h*.96f,12f,0xFF9DB2C5.toInt())
    }
    private fun drawMissions(c:Canvas,w:Float,h:Float) {
        bg(c,w,h);text(c,"MISSIONS  /  CAMPAIGN",w*.05f,h*.13f,30f,Color.CYAN,true);button(c,"BACK",w*.83f,h*.06f,w*.12f,h*.1f)
        for(i in 1..25){val col=(i-1)%5;val row=(i-1)/5;val x=w*.05f+col*w*.145f;val y=h*.23f+row*h*.135f
            button(c,if(i>unlocked)"LOCKED" else "%02d".format(i),x,y,w*.12f,h*.105f,i==mission)
        }
        text(c,"SELECT A MISSION  •  3 LEVELS EACH",w*.05f,h*.94f,14f,Color.LTGRAY)
    }
    private fun drawLevels(c:Canvas,w:Float,h:Float) {
        bg(c,w,h);text(c,"MISSION %02d".format(mission),w*.08f,h*.2f,36f,Color.CYAN,true)
        listOf("LEVEL 1  /  EASY","LEVEL 2  /  NORMAL","LEVEL 3  /  HARD").forEachIndexed{i,s->button(c,s,w*.12f+i*w*.26f,h*.43f,w*.22f,h*.2f,i==0)}
        button(c,"BACK",w*.05f,h*.06f,w*.14f,h*.1f)
        text(c,"CHOOSE YOUR FLIGHT DIFFICULTY",w*.12f,h*.8f,16f,Color.LTGRAY)
    }
    private fun drawSettings(c:Canvas,w:Float,h:Float) {
        bg(c,w,h);text(c,"SETTINGS",w*.08f,h*.2f,36f,Color.CYAN,true)
        button(c,if(showEffects)"EFFECTS: ON" else "EFFECTS: OFF",w*.12f,h*.38f,w*.34f,h*.16f,showEffects)
        button(c,"RESET CAMPAIGN",w*.54f,h*.38f,w*.34f,h*.16f)
        button(c,"BACK",w*.08f,h*.72f,w*.18f,h*.12f)
    }
    private fun drawHangar(c:Canvas,w:Float,h:Float) {
        bg(c,w,h);text(c,"HANGAR  /  SELECT AIRCRAFT",w*.06f,h*.15f,30f,Color.CYAN,true)
        planes.forEachIndexed{i,s->val col=i%3;val row=i/3;val x=w*.07f+col*w*.29f;val y=h*.3f+row*h*.29f
            rect(c,x,y,w*.23f,h*.22f,Color.rgb(16,32,48),15f);jet(c,x+w*.115f,y+h*.09f,.8f)
            text(c,s,x+w*.115f,y+h*.18f,19f,Color.WHITE,true,true);if(i==planeIndex)text(c,"SELECTED",x+w*.115f,y+h*.215f,11f,Color.CYAN,true,true)
        }
        text(c,"SELECTED: ${planes[planeIndex]}",w*.08f,h*.9f,16f,Color.CYAN,true)
        button(c,"BACK",w*.82f,h*.06f,w*.13f,h*.1f)
    }
    private fun startGame() {
        page="game";airborne=false;paused=false;world=0f;hp=100f;bombs=4;flares=3;score=0;jetY=height*.56f
        targets.clear();shots.clear();explosions.clear()
        val count=if(mission==0)40 else 8+mission+level*2
        for(i in 0 until count)targets.add(Target(520f+i*(180f+rnd.nextInt(100)),height*.76f+rnd.nextInt(max(10,height/12)).toFloat(),if(level==1)1 else level, true,i%3==0))
    }
    private fun drawGame(c:Canvas,w:Float,h:Float) {
        val now=System.nanoTime();val dt=((now-last)/16_666_667.0).toFloat().coerceIn(0f,2f);last=now
        bg(c,w,h)
        if(airborne&&!paused){
            world+=2.8f*dt
            if(left)jetY=(jetY-3f*dt).coerceAtLeast(h*.25f)
            if(right)jetY=(jetY+3f*dt).coerceAtMost(h*.68f)
            if(System.currentTimeMillis()<fireUntil && rnd.nextFloat()<.4f)shots.add(Shot(w*.31f,jetY))
            shots.forEach{it.x+=10f*dt};shots.removeAll{it.x>w+20}
            targets.forEach{t->t.x-=0.45f*dt}
            for(s in shots){val t=targets.firstOrNull{it.alive&&abs(it.x-s.x)<30&&abs(it.y-s.y)<65};if(t!=null){t.hp--;s.x=w+999;if(t.hp<=0){t.alive=false;score+=100}}}
            if(mission!=0&&targets.none{it.alive}){unlocked=max(unlocked,min(25,mission+1));paused=true}
        }
        // base structures visible during takeoff
        if(!airborne){
            rect(c,w*.62f,h*.49f,22f,h*.25f,Color.rgb(91,116,127),3f);rect(c,w*.60f,h*.46f,65f,18f,Color.rgb(118,149,160),4f)
            for(i in 0..2)jet(c,w*(.18f+i*.13f),h*.78f,.55f,Color.rgb(110,139,157))
            jet(c,w*.22f,h*.76f,1.05f)
            button(c,"TAKE OFF",w*.42f,h*.61f,w*.18f,h*.11f,true)
        } else {
            targets.filter{it.alive}.forEach{target(c,it,w)}
            shots.forEach{rect(c,it.x,it.y,20f,4f,Color.YELLOW,2f)}
            jet(c,w*.23f,jetY,1.15f)
        }
        rect(c,w*.02f,h*.03f,w*.25f,h*.1f,0xDD081522.toInt(),8f);text(c,"MISSION ${if(mission==0)"FREE" else "%02d".format(mission)}  •  SCORE $score",w*.04f,h*.095f,16f,Color.WHITE,true)
        rect(c,w*.73f,h*.03f,w*.25f,h*.1f,0xDD081522.toInt(),8f);text(c,"HULL ${hp.toInt()}%   BOMBS $bombs   FLARE $flares",w*.745f,h*.095f,13f,Color.WHITE,true)
        // touch controls
        button(c,"◀",w*.03f,h*.79f,w*.09f,h*.16f,left);button(c,"▶",w*.13f,h*.79f,w*.09f,h*.16f,right)
        button(c,"FIRE",w*.73f,h*.79f,w*.1f,h*.16f,true);button(c,"BOMB",w*.84f,h*.79f,w*.07f,h*.16f);button(c,"FLARE",w*.92f,h*.79f,w*.07f,h*.16f)
        button(c,"Ⅱ",w*.46f,h*.03f,w*.07f,h*.1f)
        if(paused){rect(c,w*.32f,h*.28f,w*.36f,h*.42f,0xEE07111E.toInt(),18f);text(c,"PAUSED / MISSION CLEAR",w*.5f,h*.4f,22f,Color.CYAN,true,true);button(c,"RETRY",w*.37f,h*.49f,w*.12f,h*.12f);button(c,"MENU",w*.52f,h*.49f,w*.12f,h*.12f)}
    }
    override fun onTouchEvent(e: android.view.MotionEvent): Boolean {
        val x=e.x;val y=e.y;val w=width.toFloat();val h=height.toFloat()
        if(e.action==MotionEvent.ACTION_UP || e.action==MotionEvent.ACTION_CANCEL){left=false;right=false;fireUntil=0L;return true}
        if(e.action!=MotionEvent.ACTION_DOWN&&e.action!=MotionEvent.ACTION_MOVE)return true
        when(page){
            "menu"->{if(x<w*.48f&&y in h*.34f..h*.49f){page="missions"}else if(x<w*.48f&&y in h*.49f..h*.63f){mission=0;level=1;startGame()}else if(x<w*.48f&&y in h*.63f..h*.77f){page="hangar"}else if(x<w*.48f&&y in h*.77f..h*.93f){page="settings"}}
            "missions"->{if(y<h*.18f&&x>w*.78f)page="menu" else if(y in h*.2f..h*.92f){val col=((x-w*.05f)/(w*.145f)).toInt();val row=((y-h*.23f)/(h*.135f)).toInt();val n=row*5+col+1;if(n in 1..unlocked){mission=n;page="levels"}}}
            "levels"->{if(y<h*.2f&&x<w*.22f)page="missions" else if(y in h*.35f..h*.75f){level=(((x-w*.12f)/(w*.26f)).toInt()+1).coerceIn(1,3);startGame()}}
            "hangar"->{if(y<h*.2f&&x>w*.78f)page="menu" else if(y>h*.25f&&y<h*.85f){val col=((x-w*.07f)/(w*.29f)).toInt();val row=if(y>h*.58f)1 else 0;planeIndex=(row*3+col).coerceIn(0,5)}}
            "settings"->{if(y>h*.7f&&x<w*.3f)page="menu" else if(y in h*.3f..h*.62f&&x<w*.5f)showEffects=!showEffects else if(y in h*.3f..h*.62f&&x>w*.5f)unlocked=1}
            "game"->{
                if(paused){if(x>w*.49f&&y>h*.45f){page="menu";paused=false}else if(x<w*.5f&&y>h*.45f){startGame()}}
                else if(y<h*.16f&&x in w*.44f..w*.56f)paused=true
                else if(!airborne&&y in h*.55f..h*.8f){airborne=true}
                else if(y>h*.75f){
                    when {
                        x<w*.12f -> { left=true; right=false }
                        x<w*.23f -> { right=true; left=false }
                        x>w*.92f && e.action==MotionEvent.ACTION_DOWN -> flares=max(0,flares-1)
                        x>w*.83f && e.action==MotionEvent.ACTION_DOWN -> bombs=max(0,bombs-1)
                        else -> fireUntil=System.currentTimeMillis()+700
                    }
                }
            }
        }
        invalidate();return true
    }
}
